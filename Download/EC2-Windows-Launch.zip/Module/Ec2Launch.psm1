# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

#
# This is Ec2 Launch script module that provides methods to initialize Ec2 instance during launch.
# All scripts are included under /Scripts directory and executed from this module. 
# You can create your own function using the scripts to initialize Ec2 instance with different configurations.
# But it is important to understand what each script does before you are using to create new function here.
# Some scripts may dependent on each other for now, but will be eliminated in the future.
#

# Set all necessary constant variables used by helper scripts.
Set-Variable cmdPath -Option Constant -Scope Script -Value (Join-Path $env:SystemRoot -ChildPath "System32\cmd.exe")
Set-Variable psPath -Option Constant -Scope Script -Value (Join-Path $env:SystemRoot -ChildPath "System32\WindowsPowerShell\v1.0\powershell.exe")
Set-Variable rootPath -Option Constant -Scope Script -Value (Join-Path $env:ProgramData -ChildPath "Amazon\EC2-Windows\Launch")
Set-Variable modulePath -Option Constant -Scope Script -Value (Join-Path $script:rootPath -ChildPath "Module")
Set-Variable moduleFilePath -Option Constant -Scope Script -Value (Join-Path $script:modulePath -ChildPath "Ec2Launch.psd1")
Set-Variable logPath -Option Constant -Scope Script -Value (Join-Path $script:rootPath -ChildPath "Log")
Set-Variable configPath -Option Constant -Scope Script -Value (Join-Path $script:rootPath -ChildPath "Config")
Set-Variable initWallpaperSetupName -Option Constant -Scope Script -Value "RunWallpaperSetupInit.cmd"
Set-Variable wallpaperSetupName -Option Constant -Scope Script -Value "RunWallpaperSetup.cmd"
Set-Variable originalWallpaperName -Option Constant -Scope Script -Value "Ec2Wallpaper.jpg"
Set-Variable customWallpaperName -Option Constant -Scope Script -Value "Ec2Wallpaper_Info.jpg"

# Dot-source all functions from scripts
$allScripts = @( Get-ChildItem -Path $PSScriptRoot\Scripts\*.ps1 -ErrorAction SilentlyContinue )
foreach ($script in $allScripts)
{
    try
    {
        . $script.Fullname
    }
    catch
    {
        Write-Error -Message "Failed to import script $($script.Fullname): $_.Exception.Message"
        return
    }
}

Export-ModuleMember -Function *