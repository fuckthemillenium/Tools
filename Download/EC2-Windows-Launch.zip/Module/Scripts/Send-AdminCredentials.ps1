# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Send-AdminCredentials
{
    param (
        [Parameter(Mandatory=$true, Position=0)]
        [string] $Username,

        [Parameter(Mandatory=$true, Position=1)]
        [string] $Password
    )

    try
    {
        # Once password is successfully generated, prepare to encrypt the password and send it to console.
        $keyString = Get-Metadata -UrlFragment "meta-data/public-keys/0/openssh-key"

        ($keyType, $base64Key) = $keyString.Split(' ', 3)[0..1]
        $keyBytes = [Convert]::FromBase64String($base64Key)

        $prefixStartIndex = 0
        $prefixLength = [BitConverter]::ToInt32($keyBytes[3..0], 0)

        $exponentStartIndex = $prefixStartIndex + $prefixLength + 4
        $exponentLength = [BitConverter]::ToInt32($keyBytes[($exponentStartIndex + 3) .. $exponentStartIndex], 0)

        $modulusStartIndex = $exponentStartIndex + $exponentLength + 4
        $modulusLength = [BitConverter]::ToInt32($keyBytes[($modulusStartIndex + 3) .. $modulusStartIndex], 0)

        $exponent = $keyBytes[($exponentStartIndex + 4) .. ($exponentStartIndex + 3 + $exponentLength)]
        $modulus = $keyBytes[($modulusStartIndex + 4) .. ($modulusStartIndex + 3 + $modulusLength)]

        if ($modulus[0] -eq 0) 
        {
            $modulus = $modulus[1 .. ($modulus.Length - 1)]
        }

        $parameters = New-Object System.Security.Cryptography.RSAParameters
        $parameters.Exponent = $exponent
        $parameters.Modulus = $modulus

        $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
        $rsa.ImportParameters($parameters)

        # Encrypt the password by RSA formed above.
        $encryptedString = $rsa.Encrypt([System.Text.Encoding]::UTF8.GetBytes($Password), $false)
        $encryptedPassword = [System.Convert]::ToBase64String($encryptedString)

        # This is an important step to inform console about the password reset. 
        # The format MUST NOT be changed!
        Write-Log ("Username: {0}" -f $Username) -LogToConsole
        Write-Log ("Password: <Password>{0}{1}{2}</Password>" -f [System.Environment]::NewLine, $encryptedPassword, [System.Environment]::NewLine) -LogToConsole    
    }
    catch
    {
        Write-Log ("Unable to send the password to console: {0}" -f $_.Exception.Message)
    }
    finally
    {
        $Password = ""
    }
}