# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Import-RunCmdUtil
{
    try
    {
        # Check if type is already added.
        $check = [RunCmdUtil]
    }
    catch
    {
        Add-Type -TypeDefinition @'
            using System;
            using System.Collections.Generic;
            using System.Runtime.InteropServices;
            namespace RunCmdUtil {
        
                [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
                public struct ProfileInfo {
                    public int dwSize;
                    public int dwFlags;
                    public string lpUserName;
                    public string lpProfilePath;
                    public string lpDefaultPath;
                    public string lpServerName;
                    public string lpPolicyPath;
                    public IntPtr hProfile;
                }

                [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
                public struct ProcessInformation {
                    public IntPtr Process;
                    public IntPtr Thread;
                    public int ProcessId;
                    public int ThreadId;
                }

                [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
                public struct StartupInfo {
                    public Int32 Size;
                    public string Reserved;
                    public string Desktop;
                    public string Title;
                    public Int32 X;
                    public Int32 Y;
                    public Int32 XSize;
                    public Int32 YSize;
                    public Int32 XCountChars;
                    public Int32 YCountChars;
                    public Int32 FillAttribute;
                    public Int32 Flags;
                    public Int16 ShowWindow;
                    public Int16 sReserved2;
                    public Int32 Reserved2;
                    public Int32 StdInput;
                    public Int32 StdOutput;
                    public Int32 StdError;
                }

                public static class PInvoke {

                    [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool LogonUser(
                        string userName,
                        string domainName,
                        IntPtr password,
                        int logonType,
                        int logonProvider,
                        out IntPtr userToken);
                    
                    [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool CreateProcessAsUser(
                        IntPtr userToken,
                        string applicationName,
                        string commandLine,
                        IntPtr processAttributes,
                        IntPtr threadAttributes,
                        bool inheritHandles,
                        int creationFlags,
                        IntPtr environment,
                        string currentDirectory,
                        ref StartupInfo startupInfo,
                        out ProcessInformation processInformation);
                    
                    [DllImport("userenv.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool LoadUserProfile(IntPtr hToken, ref ProfileInfo lpProfileInfo);

                    [DllImport("userenv.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool UnloadUserProfile(IntPtr hToken, IntPtr hProfile);
               
                    [DllImport("userenv.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool CreateEnvironmentBlock(out IntPtr lpEnvironment, IntPtr hToken, bool bInherit);

                    [DllImport("userenv.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    [return: MarshalAs(UnmanagedType.Bool)]
                    public static extern bool DestroyEnvironmentBlock(IntPtr lpEnvironment);

                }
            }
'@
    }
}
