# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Import-WallpaperUtil
{
    try 
    {
        $check = [WallpaperUtil]
    }
    catch
    {
        Add-Type -TypeDefinition @"
            using System.Runtime.InteropServices;
            using System;

            namespace WallpaperUtil {

                public static class Helper {
                    private static uint SPI_SETDESKWALLPAPER = 20;
                    private static uint SPI_GETDESKWALLPAPER = 115;
                    private static uint SPIF_UPDATEINIFILE = 0x01;
                    private static uint SPIF_SENDWININICHANGE = 0x02;
                    private static uint MAX_PATH = 1024;

                    public static void SetWallpaper(string src) {
                        PInvoke.SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, src, SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
                    }

                    public static String getWallpaper() {
                        var path = new String('\0', (int)MAX_PATH);
                        PInvoke.SystemParametersInfo(SPI_GETDESKWALLPAPER, MAX_PATH, path, SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
                        path = path.Substring(0, path.IndexOf('\0'));
                        return path;
                    }
                }

                public static class PInvoke {
                    [DllImport("user32.dll", CharSet = CharSet.Auto)]
                    public static extern uint SystemParametersInfo(
                        uint action, uint uParam, string vParam, uint winIni);
                }
            }
"@
    }
}