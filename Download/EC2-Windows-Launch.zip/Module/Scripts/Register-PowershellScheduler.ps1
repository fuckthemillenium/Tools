# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Register-PowershellScheduler registers a scheduled task that executes powershell command on next reboot.
-------------------------------------------------------------------------------------------------------------#>
function Register-PowershellScheduler
{
    param (
        [Parameter(Mandatory=$true, Position=0)]
        [string] $Command,

        [Parameter(Mandatory=$true, Position=1)]
        [string] $ScheduleName,

        [parameter(Mandatory=$false)]
        [switch] $Unregister = $false,

        [parameter(Mandatory=$false)]
        [switch] $Disabled = $false
    )
 
    $taskName = ("Amazon Ec2 Launch - {0}" -f $ScheduleName)

    if ($Unregister) 
    {
        $scheduledTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
        if ($scheduledTask) 
        {
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        }
    }
    else 
    {
        # Scheduled task is triggered at start up to execute script as local system with highest priority.
        # The task is disabled by default if Disabled argument is provided.
        $action = New-ScheduledTaskAction -Execute $script:cmdPath -Argument $Command
        $trigger = New-ScheduledTaskTrigger -AtStartup
        $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DisallowHardTerminate -DontStopIfGoingOnBatteries -DontStopOnIdleEnd -Priority 0
        $settings.Enabled = (-not $Disabled)
        $principal = New-ScheduledTaskPrincipal -UserId S-1-5-18 -LogonType ServiceAccount -RunLevel Highest
        $task = New-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -Principal $principal
        Register-ScheduledTask -TaskName $taskName -InputObject $task -Force 
    }
}