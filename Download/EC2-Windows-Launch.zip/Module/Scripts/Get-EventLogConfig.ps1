# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Get-EventLogConfig
{
    Write-Log "Reading event log config from file"
    
    # Create a event log list in script.
    $eventLogConfigs = @()

    try
    {
        $eventLogConfigPath = (Join-Path -Path $script:configPath -ChildPath "EventLogConfig.json")
        
        # Test if config file path exists 
        if (-not (Test-Path $eventLogConfigPath))
        {
            throw New-Object System.Exception("{0} not found" -f $eventLogConfigPath)
        }
        
        # Get config from the file and convert it to events array from JSON.
        $content = Get-Content $eventLogConfigPath -Raw
        $json = $content | ConvertFrom-Json
        if (-not $json.events)
        {
            throw New-Object System.Exception("Failed to find events array in config file")
        }

        $events = $json.events

        # Retrieve eventlogs by each event and send them to console in correct format. 
        foreach ($event in $events)
        {
            $event | Confirm-EventLogConfig -ErrorAction:Stop | Out-Null

            # If event doesn't contain LogName, we can't get eventlogs, so continue.
            if (-not $event.logName)
            {
                Write-Log "LogName is missing"
                continue
            }
            
            switch ($event.level)
            {
                "Error" { $level = 2; break }
                "Warning" { $level = 3; break }
                "Information" { $level = 4; break }
                default {}
            }
            
            $config = new-object PSObject
            $config | add-member -type NoteProperty -Name LogName -Value $event.logName
            $config | add-member -type NoteProperty -Name Source -Value $event.source
            $config | add-member -type NoteProperty -Name Level -Value $level
            $config | add-member -type NoteProperty -Name NumEntries -Value $event.numEntries
            $eventLogConfigs += $config
        }
    }
    catch
    {
        Write-Log ("Failed to read event log config: {0} " -f $_.Exception.Message)
    }

    # Log the event log config to inform users with detail.
    $message = "Finished reading event log config:{0}" -f [Environment]::NewLine
    foreach ($eventLogConfig in $eventLogConfigs)
    {
        $message += "LogName: {0}; Source: {1}; Level: {2}; NumEntries: {3}{4}" -f $eventLogConfig.LogName, $eventLogConfig.Source, 
                                                                $eventLogConfig.Level, $event.numEntries, [System.Environment]::NewLine
    }

    Write-Log $message

    return $eventLogConfigs
}