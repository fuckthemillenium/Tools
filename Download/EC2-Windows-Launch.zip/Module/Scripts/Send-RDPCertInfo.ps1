# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-RDPCertInfo sends Remote Desktop Protocol Certificate to console.
-------------------------------------------------------------------------------------------------------------#>
Function Send-RDPCertInfo
{
    if (Test-NanoServer)
    {
        # Nano Server does not support Remote Desktop. So it needs to check if the current platform is Nano Sever.
        # If the current platform is Nano Server, display the following message to console.
        Write-Log "RDP not supported in Nano Server" -LogToConsole
        return
    }

    try 
    {
        $computerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
        $cert = (Get-CimInstance -Namespace "root\CIMV2\TerminalServices" -ClassName Win32_TSGeneralSetting `
                    -Filter "TerminalName='RDP-Tcp'").SSLCertificateSHA1Hash

        # If it retrived RDP certificate successfully, display the computer name and thumbprint to console.
        Write-Log ("RDPCERTIFICATE-SUBJECTNAME: {0}" -f $computerName) -LogToConsole
        Write-Log ("RDPCERTIFICATE-THUMBPRINT: {0}" -f $cert) -LogToConsole
    }
    catch 
    {
        Write-Log "Unable to load RDP Cert Thumbprint: {0}" -LogToConsole
        Write-Log $_.Exception.Message
    }
}
