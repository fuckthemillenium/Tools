# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Get-Metadata retrieves metadata information from complete url
-------------------------------------------------------------------------------------------------------------#>
function Get-Metadata 
{
    param (
        # Url fragment is a mandatory argument.
        [Parameter(Mandatory=$true, Position=0)]
        [string] $UrlFragment
    )
    
    try
    {
        $InstanceMetadataUrl = "http://169.254.169.254/latest/{0}" -f $UrlFragment
        $request = [System.Net.HttpWebRequest]::CreateHttp($InstanceMetadataUrl)
        $request.Proxy = $null
        $response = $request.GetResponseAsync().Result
        if (-not $response)
        {
            throw New-Object System.Exception("The result from {0} was empty" -f $InstanceMetadataUrl)
        }

        $stream = $response.GetResponseStream()
        $streamReader = New-Object System.IO.StreamReader($stream)
        $result = $streamReader.ReadToEnd()
    }
    catch
    {
        Write-Log ("Failed to get metadata: {0}" -f $_.Exception.Message)
    }
    finally
    {
        if ($stream)
        {
            $stream.Dispose()
        }
        if ($streamReader)
        {
            $streamReader.Dispose()
        }
    }

    return $result
}
