# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Invoke-CmdAsAdmin runs command as local admin.
-------------------------------------------------------------------------------------------------------------#>
function Invoke-CmdAsAdmin
{
    param (
        [Parameter(Mandatory=$True, Position=0)]
        [string] $Username,
        
        [Parameter(Mandatory=$True, Position=1)]
        [string] $Password,

        [Parameter(Mandatory=$True, Position=2)]
        [string] $Command
    )

    # Import-RunCmdUtil must be called prior to any pinvoke below.
    Import-RunCmdUtil
    
    try
    {
        # LogonUser method logs user on the local computer and returns a pointer to access token.
        $userSafeTokenHandlePtr = [System.IntPtr]::Zero
        $passwordPtr = [System.Runtime.InteropServices.Marshal]::StringToHGlobalUni($Password)
        $logonBatch = 4 # LOGON32_LOGON_BATCH
        $logonProviderDefault = 0 # LOGON32_PROVIDER_DEFAULT
        $success = [RunCmdUtil.PInvoke]::LogonUser($Username, ".", $passwordPtr, $logonBatch, $logonProviderDefault, [ref] $userSafeTokenHandlePtr) 
        if (-not $success)
        {
            throw New-Object System.Exception("Failed to logon user")
        }
        $userSafeTokenHandle = New-Object Microsoft.Win32.SafeHandles.SafeAccessTokenHandle($userSafeTokenHandlePtr)

        # Profile must be loaded and checked before moving forward.
        $profileInfo = New-Object RunCmdUtil.ProfileInfo
        $profileInfo.lpUserName = $Username;
        $profileInfo.dwSize = [System.Runtime.InteropServices.Marshal]::SizeOf($profileInfo)
        $profileInfo.hProfile = [System.IntPtr]::Zero
        $success = [RunCmdUtil.PInvoke]::LoadUserProfile($userSafeTokenHandlePtr, [ref] $profileInfo)
        if (-not $success)
        {
            throw New-Object System.Exception("Loading the user profile failed")
        }

        if ($profileInfo.hProfile -eq [System.IntPtr]::Zero)
        {
            throw New-Object System.Exception("Loading the user profile failed - HKCU handle was not loaded")
        }
    
        # CreateEnvironmentBlock method retrieves environment variables and returns a pointer to the environment block.
        $envSafeTokenHandlePtr = [System.IntPtr]::Zero
        $success = [RunCmdUtil.PInvoke]::CreateEnvironmentBlock([ref] $envSafeTokenHandlePtr, $userSafeTokenHandlePtr, $false)
        if (-not $success)
        {
            throw New-Object System.Exception("Failed to create environment block")
        }
        $envSafeTokenHandle = New-Object Microsoft.Win32.SafeHandles.SafeAccessTokenHandle($envSafeTokenHandlePtr)

        [System.Action] $action = {
            $procInfo = New-Object RunCmdUtil.ProcessInformation
            $startupInfo = New-Object RunCmdUtil.StartupInfo
            $startupInfo.Size = [System.Runtime.InteropServices.Marshal]::SizeOf($startupInfo)
            $procCreationFlags = 0x00000020 -bor 0x00000010 -bor 0x00000400 # NormalPriorityClass | CreateNewConsole | CreateUnicodeEnvironment
            $success = [RunCmdUtil.PInvoke]::CreateProcessAsUser($userSafeTokenHandlePtr, [NullString]::Value, $command, [System.IntPtr]::Zero, [System.IntPtr]::Zero, $false, $procCreationFlags, $envSafeTokenHandlePtr, [NullString]::Value, [ref] $startupInfo, [ref] $procInfo)
            if (-not $success)
            {
                throw New-Object System.Exception("Create process as user failed")
            }

            $sleepTime = 1
            $count = 0
            $proc = [System.Diagnostics.Process]::GetProcessById($procInfo.ProcessId)
            while (-not $proc.HasExited) 
            {
                if ($count -gt 0 -and ($count * $sleepTime) % 120 -eq 0)
                {
                    # This message will be logged to log file every 2 minute
                    Write-Log ("{0}: {1} is currently executing. To end it kill the process with id: {2}" -f "Userdata", $proc.StartInfo.FileName, $proc.Id)
                }

                Start-Sleep -seconds $sleepTime
                $count++
                $proc.Refresh()
            }
            $proc.WaitForExit()
        }

        [System.Security.Principal.WindowsIdentity]::RunImpersonated($userSafeTokenHandle, $action)
    }
    catch
    {
        Write-Log ("Unable to finish userdata as admin: {0}" -f $_.Exception.Message)
    }
    finally
    {
        if($envSafeTokenHandlePtr)
        {
            $silent = [RunCmdUtil.PInvoke]::DestroyEnvironmentBlock($envSafeTokenHandlePtr)
            $envSafeTokenHandle.Close()
            $envSafeTokenHandle.Dispose()
        }

        if($userSafeTokenHandlePtr)
        {
            if($profileInfo)
            {
                $silent = [RunCmdUtil.PInvoke]::UnloadUserProfile($userSafeTokenHandlePtr, $profileInfo.hProfile)
            }
            $userSafeTokenHandle.Close()
            $userSafeTokenHandle.Dispose()
        }

        [System.Runtime.InteropServices.Marshal]::FreeHGlobal($passwordPtr)
    }
}
