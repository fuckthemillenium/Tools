# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-DriverInfo sends information of all drivers recommended by Amazon to console.
-------------------------------------------------------------------------------------------------------------#>
function Send-DriverInfo 
{
    try 
    {
        if (-not (Test-NanoServer))
        {
            $xenDrivers = Get-CimInstance -ClassName Win32_PnPEntity | Where-Object { $_.Service -eq 'xenvbd' }
            $drivers = Get-CimInstance -ClassName Win32_PnPSignedDriver | Where-Object { $_.DeviceID -eq $xenDrivers.DeviceID -or ( $_.DeviceClass -eq 'Net' -and `
                ($_.Manufacturer -like 'Intel*' -or $_.Manufacturer -eq 'Citrix Systems, Inc.' -or $_.Manufacturer -eq 'Amazon Inc.' -or $_.Manufacturer -eq 'Amazon Web Services, Inc.')) }
            foreach ($driver in $drivers) 
            {
                Write-Log ("Driver: {0} v{1} " -f $driver.Description, $driver.DriverVersion) -LogToConsole
            }
        }
        else
        {
            # Nano Server does not contain Win32_PnPSignedDriver object, so it uses different approach to get driver name and version.
            # This approach takes longer time because Get-WindowsDriver retrieves all windows drivers.
            $win_drivers = Get-WindowsDriver -Online | Where-Object { $_.OriginalFileName -like '*xenvbd*' -or $_.ClassName -eq 'Net' -and `
                ($_.ProviderName -eq 'Amazon Inc.' -or $_.ProviderName -eq 'Citrix Systems, Inc.' -or $_.ProviderName -like 'Intel*' -or $_.ProviderName -eq 'Amazon Web Services, Inc.') }
            $pnp_drivers = Get-CimInstance -ClassName Win32_PnPEntity | Where-Object { $_.Service -eq 'xenvbd' -or `
                 $_.Manufacturer -like 'Intel*' -or $_.Manufacturer -eq 'Citrix Systems, Inc.' -or $_.Manufacturer -eq 'Amazon Inc.' -or $_.Manufacturer -eq 'Amazon Web Services, Inc.' }
            foreach ($win_driver in $win_drivers) 
            {
                foreach ($pnp_driver in $pnp_drivers) 
                {
                    if ($pnp_driver.Service -and $win_driver.OriginalFileName -like ("*{0}*" -f $pnp_driver.Service)) 
                    {
                        Write-Log ("Driver: {0} v{1} " -f $pnp_driver.Name, $win_driver.Version) -LogToConsole
                    }
                }
            }
        }
    }
    catch
    {
        Write-Log "Unable to load driver information" -LogToConsole
        Write-Log $_.Exception.Message
    }
}