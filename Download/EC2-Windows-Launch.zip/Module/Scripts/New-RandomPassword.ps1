# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    New-RandomPassword generates and returns a random password that meets Windows Password Requirement Policy. 
-------------------------------------------------------------------------------------------------------------#>
function New-RandomPassword
{
    $password = ""
    
    do
    {
        # 1024 bytes are randomly generated.
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        $randomBytes = New-Object Byte[] 1024
        $rng.GetBytes($randomBytes)

        # Special character contains the following: ()!@$%-=.?*;& 
        $specialChars = @(40, 41, 33, 64, 36, 37, 45, 61, 46, 63, 42, 59, 38) 

        # First 32 characters that meet the given conditions are picked from the random bytes.
        $password = [System.Text.Encoding]::ASCII.GetString(($randomBytes | where { `
                                                            ($_ -ge 97 -and $_ -le 122) -or ` # a - z
                                                            ($_ -ge 65 -and $_ -le 90) -or  ` # A - Z
                                                            ($_ -ge 50 -and $_ -le 57) -or  ` # 2 - 9
                                                            ($specialChars -contains $_) }) ` # ()!@$%-=.?*;& 
                                                            )

        # Passwords must contain characters from three of the four categories and longer than 32
    } while (-not (Confirm-Password -Password $password) -or $password.Length -lt 32) 
    
    return $password.Substring(0, 32)
}