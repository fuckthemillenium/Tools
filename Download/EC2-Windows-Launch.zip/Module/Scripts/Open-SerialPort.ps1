# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Open-SerialPort opens COM port and must be done prior to writing anything to it.
-------------------------------------------------------------------------------------------------------------#>
function Open-SerialPort
{
    Write-Log "Opening COM port handle to write to the console"

    # Initialize the variables needed for logging messages to console.
    Set-Variable spFileHandle -Scope Script -Value ([System.IntPtr]::Zero)
    Set-Variable spSafeFileHandle -Scope Script -Value ($null)
    Set-Variable spStream -Scope Script -Value ($null)

    $genericRead = 2147483648 # 0x80000000
    $genericWrite = 1073741824 # 0x40000000

    $openExisting = 3

    $cbr115200 = 115200;
    $oneStopBit = 0;
    $noParity = 0;
    $byteSize = 8;    

    $sleepTime = 1
    $count = 0

    while ($true) 
    {
        try
        {
            # Import-SerialPortUtil must be called prior to any pinvoke below.
            Import-SerialPortUtil

            # Open Serial Port COM1
            $script:spFileHandle = [SerialPortUtil.PInvoke]::CreateFile("\\.\COM1", $genericRead -bor $genericWrite, 0, [System.IntPtr]::Zero, $openExisting, 0, [System.IntPtr]::Zero)
            if ($script:spFileHandle -eq -1)
            {
                throw New-Object System.InvalidOperationException("[SerialPortUtil.PInvoke]::CreateFile failed - HR error code: {0}" -f [System.Runtime.InteropServices.Marshal]::GetLastWin32Error());
            }

            # Get control setting for Serial Port COM1 
            $dcb = New-Object SerialPortUtil.Dcb
            $success = [SerialPortUtil.PInvoke]::GetCommState($spFileHandle, [ref] $dcb)
            if (-not $success) 
            {
                throw New-Object System.InvalidOperationException("GetCommState failed - HR error code: {0}" -f [System.Runtime.InteropServices.Marshal]::GetLastWin32Error());
            }

            # Check if control settings values are set to desired values
            if ($dcb.BaudRate -ne $cbr115200 -or $dcb.ByteSize -ne $byteSize -or $dcb.Parity -ne $noParity -or $dcb.StopBits -ne $oneStopBit)
            {
                $dcb.BaudRate = $cbr115200
                $dcb.StopBits = $oneStopBit
                $dcb.Parity = $noParity
                $dcb.ByteSize = $byteSize

                $success = [SerialPortUtil.PInvoke]::SetCommState($spFileHandle, [ref] $dcb)
                if (-not $success)
                {
                    throw New-Object System.InvalidOperationException("SetCommState failed - HR error code: {0}" -f [System.Runtime.InteropServices.Marshal]::GetLastWin32Error());
                }
            }

            # Create a safe file handle
            $script:spSafeFileHandle = New-Object Microsoft.Win32.SafeHandles.SafeFileHandle($script:spFileHandle, $true)

            # Create a stream with the safe file handle
            $script:spStream = New-Object System.IO.FileStream($script:spSafeFileHandle, [System.IO.FileAccess]::ReadWrite)
            if ($script:spStream)
            {
                # Break if stream is succesfully created.
                break
            }
        } 
        catch 
        {
            Close-SerialPort
        }
        
        # It logs the status every 1 minutes.
        if (($count * $sleepTime) % 60 -eq 0) 
        { 
            Write-Log "Serial Port in use. Waiting for Serial Port..."
        }

        Start-Sleep -seconds $sleepTime
        $count ++
    }
}