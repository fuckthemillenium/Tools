#----------------------------------------------------------------------------------------------------
  #
  #    Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
  #
  #    Licensed under the Customer Agreement (the "License"). 
  #
  #    You may not use this file except in compliance with the License. 
  #
  #    A copy of the License is located at
  #
  #          http://aws.amazon.com/agreement  
  #
  #    or in the "license" file accompanying this file. 
  #
  #    This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
  #    either express or implied. See the License for the specific language governing permissions 
  #    and limitations under the License.
  #
  #----------------------------------------------------------------------------------------------------
  
  function Get-HttpResource($url)
  {
      try 
      {
          $request = [System.Net.WebRequest]::Create($url)
          $request.timeout="5000"
          $response = $request.GetResponse()
          $statusCode = ($response.Statuscode) -as [int]
  
          if ($statusCode -ne "200")
          {
              return $null;
          }
  
          $stream = $response.GetResponseStream()
          $sr = new-object System.IO.StreamReader $stream
          $result = $sr.ReadToEnd()
          return $result
      } 
      catch 
      {
          return $null;
      }
  }
  
  function Get-HttpBinaryFile($url, $proxy, $file)
  {
      try 
      {
          $webProxy = New-Object System.Net.WebProxy($proxy,$false)
          $request = [System.Net.WebRequest]::Create($url)
          $request.timeout="120000"
          $request.Proxy = $webProxy
          $response = $request.GetResponse()
          $statusCode = ($response.Statuscode) -as [int]
  
          if ($statusCode -ne "200")
          {
              return $false;
          }
  
          $stream = $response.GetResponseStream()
          $ms = new-object System.IO.MemoryStream
  
          $stream.CopyTo($ms)
  
          $data = $ms.ToArray()
  
          [System.IO.File]::WriteAllBytes($file, $data)
  
          return $true
      } 
      catch 
      {
          return $false;
      }
  }
  
  function Send-HttpPostJson($url, $proxy, $json)
  {
      try 
      {    
          $webProxy = New-Object System.Net.WebProxy($proxy,$false)
          $request = [System.Net.WebRequest]::Create($url)
          $request.Method = "POST"
          $request.ContentType='application/json; charset=utf-8'
          $request.Proxy = $webProxy
  
          $stream = $request.GetRequestStream()
          $streamWriter = New-Object System.IO.StreamWriter($stream)
          $streamWriter.Write($json)
          $streamWriter.Dispose();
          $stream.Dispose();
  
          $request.timeout="20000"
          $response = $request.GetResponse()
          $statusCode = ($response.Statuscode) -as [int]
  
          if ($statusCode -ne "200")
          {
              return $null;
          }
  
          $reqstream = $response.GetResponseStream()
          $sr = new-object System.IO.StreamReader $reqstream
          $result = $sr.ReadToEnd()
          return $result
      } 
      catch 
      {
          return $null;
      }        
  }
  
  function Pop-DnLexerChar([System.Text.StringBuilder]$dn)
  {
      if ($dn.Length -gt 0)
      {
          $res = Read-DnLexerChar $dn
          [void]$dn.Remove([int]0,[int]1)
          return $res
      }
      throw "Invalid DN - unexpected end"
  }
  
  function Read-DnLexerChar([System.Text.StringBuilder]$dn)
  {
      if ($dn.Length -gt 0)
      {
          [char[]] $arr = 'c'
          [void]$dn.CopyTo(0, $arr, 0, 1)
  
          return $arr[0]
      }
      return '`0'
  }
  
  function Skip-DnLexerWhitespace([System.Text.StringBuilder]$dn)
  {
      while ($true)
      {
          $c = Read-DnLexerChar $dn
          if ($c -eq '`0' -or ![System.Char]::IsWhiteSpace($c))
          {
              break
          }
          [void](Pop-DnLexerChar $dn)
      }
  }
  
  function Skip-DnLexerToCommaOrSemicolon([System.Text.StringBuilder]$dn)
  {
      while ($true)
      {
          $c = Read-DnLexerChar $dn
          if ($c -eq ',' -or $c -eq ';')
          {
              [void](Pop-DnLexerChar $dn)
              break
          }
          if ($c -eq '`0')
          {
              break
          }
          if  (![System.Char]::IsWhiteSpace($c))
          {
              throw "Unexpected character when comma was expected"
          }
          [void](Pop-DnLexerChar $dn)
      }
  }
  
  function Read-DnAttributeKey([System.Text.StringBuilder]$dn)
  {
      Skip-DnLexerWhitespace $dn
      if ((Read-DnLexerChar $dn) -eq '`0')
      {
          return $null
      }
      
      $attrkey = ""
      for($c = (Pop-DnLexerChar $dn); $c -ne '=' -and $c -ne '+'; $c = (Pop-DnLexerChar $dn))
      {
          $attrkey = $attrkey + $c
      }
  
      $attrkey = $attrkey.Trim().ToUpper()
  
      if ($attrkey.Length -eq 0)
      {
          throw "Invalid DN - empty attribute key"
      }
  
      return $attrkey
  }
  
  function Read-DnAttributeValue([System.Text.StringBuilder]$dn)
  {
      [void](Skip-DnLexerWhitespace $dn)
  
      if ((Read-DnLexerChar $dn) -eq '"')
      {
          [void](Pop-DnLexerChar $dn)
          $val = Read-DnAttributeValueWithTerminator $dn '"' '"'
          [void](Skip-DnLexerToCommaOrSemicolon $dn)
          return $val
      }
  
      return Read-DnAttributeValueWithTerminator $dn ',' ';'
  }
  
  function Test-DnLexerIsHexDigit($escaped)
  {
      if ([System.Char]::IsDigit($escaped))
      {
          return $true
      }
      if ($escaped -ge 'a' -and $escaped -le 'f')
      {
          return $true
      }
      if ($escaped -ge 'A' -and $escaped -le 'F')
      {
          return $true
      }
      return $false
  }
  
  function Add-DnLexerPendingWhitespaceToBytestream([System.Collections.Generic.List[System.Byte]] $byteStream, [System.String]$pendingWhitespace)
  {
      if ($pendingWhitespace.Length -gt 0)
      {
          $byteStream.AddRange([System.Text.Encoding]::UTF8.GetBytes($pendingWhitespace))
      }
  
      return ''
  }
  
  function Add-DnLexerBytestream([System.Collections.Generic.List[System.Byte]] $byteStream, [System.Char]$c)
  {
      if ($c -le 0x7f)
      {
          $byteStream.Add($c)
      }
      else
      {
          $byteStream.AddRange([System.Text.Encoding]::UTF8.GetBytes($c))
      }    
  }
  
  function Read-DnAttributeValueWithTerminator([System.Text.StringBuilder]$dn, $terminator1, $terminator2)
  {
      [System.Collections.Generic.List[System.Byte]]$byteStream = (New-Object System.Collections.Generic.List[System.Byte])
      [string]$accumulatedWhitespace = ''
  
      while ((Read-DnLexerChar $dn) -ne '`0')
      {
          $c = Pop-DnLexerChar $dn
  
          if ($c -eq $terminator1 -or $c -eq $terminator2)
          {
              break
          }
  
          if ($c -eq '\')
          {
              $escaped = Pop-DnLexerChar $dn
              
              $accumulatedWhitespace = Add-DnLexerPendingWhitespaceToBytestream $byteStream $accumulatedWhitespace
  
              if ((Test-DnLexerIsHexDigit $escaped))
              {
                  $next = Pop-DnLexerChar $dn
                  $hex = "" + $escaped + $next
                  $byteStream.Add([System.Byte]::Parse($hex,[System.Globalization.NumberStyles]::HexNumber))
              }
              else
              {
                  Add-DnLexerBytestream $byteStream $escaped 
              }
          }
          elseif ([System.Char]::IsWhiteSpace($c))
          {
              $accumulatedWhitespace += $c
          }
          else 
          {
              $accumulatedWhitespace = Add-DnLexerPendingWhitespaceToBytestream $byteStream $accumulatedWhitespace
              Add-DnLexerBytestream $byteStream $c 
          }
      }
      
      $str = [System.Text.Encoding]::UTF8.GetString($byteStream.ToArray())
      return $str
  }
  
  function Read-DistinguishedName($rdn)
  {
      [System.Text.StringBuilder]$dn = New-Object System.Text.StringBuilder
      [void]$dn.Append($rdn)
      
      $result = @{}
  
      while ($dn.Length -gt 0)
      {
          $key = Read-DnAttributeKey $dn
          $value = Read-DnAttributeValue $dn
  
          if ($key -eq $null) {
              continue
          }
  
          [void]$result.Add($key,$value)
          [void](Skip-DnLexerWhitespace $dn)
      }
      return $result
  }
  
  function Test-DnConstraints($rdn, $constraints) 
  {
      [System.Collections.Hashtable]$constr = Read-DistinguishedName $constraints
      [System.Collections.Hashtable]$subj = Read-DistinguishedName $rdn
  
      foreach ($kvp in $constr.GetEnumerator()) 
      {
          if ($subj.ContainsKey($kvp.Key))
          {
              if ($subj[$kvp.Key] -ne $kvp.Value)
              {
                  [System.Console]::WriteLine("Signature check failed : '$($subj[$kvp.Key])' != '$($kvp.Value)'")
                  return $false
              }
          }
          else
          {
              [System.Console]::WriteLine("Signature check failed : $($kvp.Key) field missing")
              return $false
          }
      }
  
      return $true
  }
    
  function Test-CertificateIsAws($file)
  {
      $auth = Get-AuthenticodeSignature $file
      $subj = $auth.SignerCertificate.Subject
  
      $dnAws = "CN=`"Amazon Web Services, Inc.`", O=`"Amazon Web Services, Inc.`", L=Seattle, S=Washington, C=US"
      $dnAmzn = "CN=Amazon Services LLC, OU=Software Services, O=Amazon Services LLC, L=Seattle, S=Washington, C=US"
  
      return ($auth.Status -eq "Valid") -and ((Test-DnConstraints $subj $dnAws) -or (Test-DnConstraints $subj $dnAmzn))
  }
  
  function Get-EgpuSoftwareVersion($key)
  {
      try
      {
          $item = Get-ItemProperty -Path ("HKLM:\SOFTWARE\Amazon\EC2ElasticGPUs\$key") -ErrorAction "Ignore"
  
          if ($item -eq $null)
          {
              return $null
          }
  
          return $item.Version
      }
      catch
      {
          return $null
      }
  }
  
  function Install-EgpuManager()
  {
      try 
      {
        
        $installedVer = Get-EgpuSoftwareVersion "EC2ElasticGPUs_Manager"
    
        if (($installedVer -ne "") -and ($installedVer -ne $null))
        {
            Write-Log "ElasticGPU already installed - version $installedVer"
        }
    
        $metadataAvailable = Get-HttpResource "http://169.254.169.254/latest/meta-data/"
    
        if ($metadataAvailable -eq $false)
        {
            Write-Log "Metadata cannot be accessed on this instance"
        }
    
        $request = Get-HttpResource "http://169.254.169.254/latest/meta-data/elastic-gpus/associations"
    
        if ($request -eq $null)
        {
            Write-Log "EG is not available on this instance"
        }
    
        $egpu = $request.Split("\r\n")[0]
    
        $egpuInfo = Get-HttpResource "http://169.254.169.254/latest/meta-data/elastic-gpus/associations/$egpu"
        $json = ConvertFrom-Json $egpuInfo
        $proxy = "http://$($json.connectionConfig.ipv4Address):$($json.connectionConfig.port)"
    
        $versionsJson = Send-HttpPostJson "http://gam:8080/gam/rest/versions" $proxy "{}"
        $downloadUrl = (ConvertFrom-Json $versionsJson).components[0].path
    
        $guid = [System.Guid]::NewGuid().ToString("N")
        $file = "$env:temp\egaim_$guid.msi"
        $logfile = "$env:temp\egaim_$guid.log"
    
        $downloadSuccess = Get-HttpBinaryFile http://gam:8080/$downloadUrl $proxy $file
    
        if ($downloadSuccess -eq $false)
        {
            Write-Log "Download failed"
        }
    
        $signatureValid = Test-CertificateIsAws $file
    
        if ($signatureValid)
        {
            Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$file`" /qn /log `"$logfile`"" -Wait -Passthru | out-null
        }
        else
        {
            Write-Log "Signature is not valid"
        }
    
        $installedVer = Get-EgpuSoftwareVersion "EC2ElasticGPUs_Manager"
    
        if (($installedVer -eq "") -or ($installedVer -eq $null))
        {
            Write-Log "ElasticGPUs installation failed ?"
        }
    
        Write-Log "Installed ElasticGPUs manager $installedVer"
    
        Remove-Item $file
    }
    catch
    {
        Write-Log "Error installing eGPU"
    }
  }
  
  