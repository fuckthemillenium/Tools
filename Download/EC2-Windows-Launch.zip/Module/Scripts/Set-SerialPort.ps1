# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Set-SerialPort sets serial port COM1 to be available.
-------------------------------------------------------------------------------------------------------------#>
function Set-SerialPort
{
    $Name = "Communications Port"
    $Port = "COM1"
    $ComDB = "ComDB"
    $DeviceParameters = "Device Parameters"
    $CCSEnumRegPath = "HKLM:\SYSTEM\CurrentControlSet\Enum"
    $COMInfoRegPath = "HKLM:\SYSTEM\CurrentControlSet\Control\COM Name Arbiter"

    Write-Log "Checking Serial Port COM1"

    # If serial port COM1 is already detected by system, return false.
    $SP = Get-CimInstance Win32_SerialPort
    if($SP -and ($SP.DeviceID -eq $Port)) {
        Write-Log "Serial Port COM1 is already set. No reboot queued."
        return $false
    }

    Write-Log "Serial Port COM1 is not set... Setting it"

    # Check if Communications Port is available.
    $CP = Get-CimInstance Win32_PnPEntity | Where Description -Contains $Name
    $DeviceId = $CP.DeviceID

    # Check if device info contains FriendlyName.
    $DeviceInfoRegPath = Join-Path $CCSEnumRegPath -ChildPath $DeviceId
    $DeviceInfo = Get-ItemProperty -Path $DeviceInfoRegPath
    if(-not $DeviceInfo.FriendlyName) {
        $FriendlyName = "{0} ({1})" -f $Name, $Port
        New-ItemProperty -Path $DeviceInfoRegPath -Name "FriendlyName" -Value $FriendlyName
    }

    # Check if port info contains PortName.
    $PortInfoRegPath = Join-Path $DeviceInfoRegPath -ChildPath $DeviceParameters
    $PortInfo = Get-ItemProperty -Path $PortInfoRegPath
    if(-not $PortInfo.PortName) {
        New-ItemProperty -Path $PortInfoRegPath -Name "PortName" -Value $Port
    }
    
    # Check if COM info contains COM DB and COM1 as 1.
    $COMInfo = Get-ItemProperty -Path $COMInfoRegPath
    if(-not $COMInfo.ComDB) {
        $ComArray = New-Object Byte[] 32
        $ComArray[0] = 1
        New-ItemProperty -Path $COMInfoRegPath -Name $ComDB -Value ([byte[]] $ComArray) 
    } elseif(($COMInfo.ComDB[0] -band 1) -eq 0) {
        $ComArray = $COMInfo.ComDB
        $ComArray[0] = $ComArray[0] -bor 1
        Set-ItemProperty -Path $COMInfoRegPath -Name $ComDB -Value ([byte[]] $ComArray) 
    }

    return $true
}
