# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Initialize-Ec2Disk brings online, partitions and formats disk.
-------------------------------------------------------------------------------------------------------------#>
function Initialize-Ec2Disk
{
    param (
        [Parameter(Mandatory=$true, Position=0)]
        [int] $DiskIndex,

        [Parameter(Mandatory=$true, Position=1)]
        [int] $EphemeralCount,

        [Parameter(Mandatory=$true, Position=2)]
        [bool] $IsEphemeral = $false
    )

    Write-Log ("Initializing disk {0} begins" -f $DiskIndex)

    $isLargeDisk = $false

    try
    {
        # If the disk size exceeds 2199023255551 bytes (2 TB), 
        # the disk must use GPT partition table.
        $disk = Get-Disk -Number $DiskIndex
        if ($disk.Size -gt 2199023255551)
        {
            $isLargeDisk = $true
        }
    }
    catch
    {
        Write-Log ("Failed to get disk size: {0}" -f $_.Exception.Message)
    }

    try
    {
        Write-Log ("Initializing the disk ...")
        
        if (-not $isLargeDisk)
        {
            Initialize-Disk -Number $DiskIndex -PartitionStyle MBR | Out-Null
        }
        else 
        {
            Initialize-Disk -Number $DiskIndex -PartitionStyle GPT | Out-Null
        }
    }
    catch
    {
        Write-Log ("Failed to initialize disk: {0}" -f $_.Exception.Message)
    }

    $driveLetter = ""

    try
    {
        Write-Log "Looking for drive letter ..."

        # Driver letter is used to format the volume on the created/existing parition.
        # If the disk is ephmeral (instance storage), drive letter starts from Z.
        # Otherwise, drive letter starts from D.
        if ($IsEphemeral)
        {
            # One-liner to get next available drive letter from Z to A.
            for($i=91;Get-PSDrive($driveLetter=[char]--$i)2>$null){}
        }
        else 
        {
            # One-liner to get next available drive letter from A to Z.
            for($i=67;Get-PSDrive($driveLetter=[char]++$i)2>$null){}
        }
    }
    catch
    {
        Write-Log ("Failed to initialize disk: {0}. There is no available drive letter left to use" -f $DiskIndex)
        return ""
    }

    try
    {
        # Stop Shell HW Detection service to prevent the prompt to pop up.
        Stop-Service -Name ShellHWDetection -ErrorAction SilentlyContinue

        Write-Log ("Creating partition with drive letter {0} ..." -f $driveLetter)
        
        # Create a partition with the given drive index and letter.
        if (-not $isLargeDisk)
        {
            $partitioned = New-Partition $DiskIndex -MbrType IFS -DriveLetter $driveLetter -UseMaximumSize -IsActive
        }
        else
        {
            $partitioned = New-Partition $DiskIndex -GptType '{ebd0a0a2-b9e5-4433-87c0-68b6b72699c7}' -DriveLetter $driveLetter -UseMaximumSize
        }

        # Check if volume is formatted for the disk.
        # If volume is not in OK status, we need to format the volume with given parameters.
        $formatted = Get-Volume -DriveLetter $driveLetter
        if (-not $formatted -or $formatted.OperationalStatus -ne "OK")
        {
            Write-Log "Formatting the volume ..."

            # Format the volume on the created/exsiting partition using the drive letter.
            if ($IsEphemeral)
            {
                $formatted = Format-Volume -DriveLetter $driveLetter -FileSystem NTFS -NewFileSystemLabel "Temporary Storage $($EphemeralCount)" -Confirm:$false
            }
            else 
            {
                $formatted = Format-Volume -DriveLetter $driveLetter -FileSystem NTFS -Confirm:$false
            }
        }
        else
        {
            throw New-Object System.Exception("Volume already has been formatted.")
        }

        # This updates the drive info
        Get-PSDrive | Out-Null

        Write-Log ("Disk {0} is successfully initialized, partitioned and formatted" -f $DiskIndex)
      
        return $driveLetter
    }
    catch
    {
        Write-Log ("Failed to initialize disk {0}: {1}" -f $DiskIndex, $_.Exception.Message)
    }
    finally
    {
        # Start the service back.
        Start-Service -Name ShellHWDetection -ErrorAction SilentlyContinue
    }

    return ""
}