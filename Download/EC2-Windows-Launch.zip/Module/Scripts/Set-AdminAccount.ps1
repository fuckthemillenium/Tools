# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Set-AdminAccount generates a random password and send it to console in encrypted format with tags
    When console receives the password, it understands the password and allow user to decrypt the password
    with the private key. Also, it enables the admin.
-------------------------------------------------------------------------------------------------------------#>
function Set-AdminAccount
{
    $creds = @{ Username = ""; Password = ""; }
     
    try
    {
        # First, we need to check if admin password type is set to Specify or Random in config.
        $adminPasswordType = Get-LaunchConfig -Key AdminPasswordType

        # If the retrieved admin password type is "Specify", attempt to read it from config. 
        if ($adminPasswordType -ieq "Specify")
        {
            Write-Log "Config indicates that a password was specified. Reading it from config..."    
             
            $password = Get-LaunchConfig -Key AdminPassword -Delete

            # If specifed password is invalid or doesn't meet the windows password policy requirement, set it to empty.
            if (-not $password -or -not (Confirm-Password -Password $password))
            {
                Write-Log "The password specified in config is empty or doesn't meet the windows requirement"  
                $password = ""
            }
        }
        elseif ($adminPasswordType -ieq "DoNothing")
        {
            # Do nothing if admin password type is DoNothing.
            Write-Log "Config indicates do nothing for password"    
            return $creds
        }

        # If password is empty, generate a random password
        if (-not $password)
        {
            Write-Log "Generating a random password..."
            $password = New-RandomPassword
        }
        
        # Finally, the password is ready to be set.
        $user = Get-CimInstance -ClassName Win32_UserAccount | Where-Object {$_.LocalAccount -eq $true -and $_.SID -like 'S-1-5-21-*' -and $_.SID -like '*-500'}

        # Set the admin password and enable the admin account.
        net user $user.Name $password /ACTIVE:YES /LOGONPASSWORDCHG:NO /EXPIRES:NEVER /PASSWORDREQ:YES

        # Set credentials for return value
        $creds.Username = $user.Name
        $creds.Password = $password
    } 
    catch
    {
        Write-Log ("Unable to reset the password: {0}" -f $_.Exception.Message)
    }
    finally
    {
        $password = ""
    }
    
    return $creds
}
