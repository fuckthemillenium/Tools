# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Register-FunctionScheduler registers a scheduled task that executes a module function.
-------------------------------------------------------------------------------------------------------------#>
function Register-FunctionScheduler
{
    param (
        [parameter(Mandatory=$true, Position=0)]
        [string] $Function,

        [parameter(Mandatory=$false, Position=1)]
        [string] $Arguments,

        [parameter(Mandatory=$false, Position=2)]
        [string] $ScheduleName,

        # This argument ensures the task to be unregistered.
        [parameter(Mandatory=$false)]
        [switch] $Unregister
    )
    
    try
    {
        # Script must be exeucted with -NoProfile to reduce the execution delay and -ExecutionPolicy Unrestricted to grant the permission.
        $psCommand = "/C {0} -NoProfile -NonInteractive -NoLogo -ExecutionPolicy Unrestricted `"Import-Module `"{1}`"; {2} {3}`"" -f $script:psPath, $script:moduleFilePath, $Function, $Arguments
        if ($Unregister)
        {
            Register-PowershellScheduler -ScheduleName $ScheduleName -Command $psCommand -Unregister
        }
        else
        {
            Register-PowershellScheduler -ScheduleName $ScheduleName -Command $psCommand
        }
    }
    catch
    {
        Write-Log ("Failed to schedule a task: {0}" -f $_.Exception.Message)
    }  
}